g.gutentags_cache_dir = os.getenv("HOME")..'/.cache/gutentags/'
g.gutentags_resolve_symlinks = 1
