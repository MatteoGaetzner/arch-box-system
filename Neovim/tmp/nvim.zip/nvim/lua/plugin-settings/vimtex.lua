require("utils")

g.vimtex_view_method = 'zathura'
g.vimtex_compiler_latexmk = {['build_dir'] = "out"}
